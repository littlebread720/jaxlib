``jax.dtypes`` module
=====================

.. automodule:: jax.dtypes

.. autosummary::
  :toctree: _autosummary

    bfloat16
    canonicalize_dtype
    float0
    issubdtype
    result_type
    scalar_type_of
